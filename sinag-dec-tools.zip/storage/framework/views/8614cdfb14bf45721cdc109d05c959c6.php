<section x-data="deathlog"  x-init="init('<?php echo e(Auth::user()->ao_character_id); ?>')">
    <?php if (isset($component)) { $__componentOriginal9914b83164616fc828dee591eec2a324 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9914b83164616fc828dee591eec2a324 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.card.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('title', null, []); ?> 
            <?php echo e(__('Regear')); ?>

         <?php $__env->endSlot(); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginale5a9133b910c265c6141ef7a07401ae3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5a9133b910c265c6141ef7a07401ae3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.master-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.master-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5a9133b910c265c6141ef7a07401ae3)): ?>
<?php $attributes = $__attributesOriginale5a9133b910c265c6141ef7a07401ae3; ?>
<?php unset($__attributesOriginale5a9133b910c265c6141ef7a07401ae3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5a9133b910c265c6141ef7a07401ae3)): ?>
<?php $component = $__componentOriginale5a9133b910c265c6141ef7a07401ae3; ?>
<?php unset($__componentOriginale5a9133b910c265c6141ef7a07401ae3); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('content', null, []); ?> 
            <div class="overflow-x-auto" x-show="data.length == 0">
                &nbsp;
            </div>
            <template x-if="data.length > 0">
                <div class="overflow-x-auto" >
                    <table id="table" class="min-w-full table-auto">
                            <thead class="font-medium">
                                <tr class=" border-gray-700 dark:border-gray-700">
                                    <th scope="col" class="text-start py-3 px-5">
                                        <?php echo e(__('Name')); ?>

                                    </th>
                                    <th scope="col" class="text-start py-3 px-5">
                                        <?php echo e(__('Equipment Lost')); ?>

                                    </th>
                                    <th scope="col" class="text-start py-3 px-5">
                                        <?php echo e(__('Killer')); ?>

                                    </th>
                                    <th scope="col" class="text-start py-3 px-5">
                                        <?php echo e(__('Timestamp')); ?>

                                    </th>
                                    <th scope="col" class="text-start py-3 px-5">
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>
                            <tbody>

                            <template x-for="item in data">
                                    <tr class="border-t-2 border-gray-700 dark:border-gray-700 text-start">
                                        <td class="border-t py-3 px-5" x-text='item.name'></td>
                                        <td class="dark:border-gray-700 py-1 px-5">
                                            <template x-for="equips in item.equipment.split(',')">
                                                <img :class="{'opacity-25 grayscale': equips.includes('!') }" class="inline" x-bind:src="`https://render.albiononline.com/v1/item/${equips.includes('!no_') ? 'QUESTITEM_TOKEN_ADC_FRAME' : equips.includes('!') ? equips.substring(1) : equips }?size=48`" alt="">
                                            </template>
                                        </td>
                                        <td class="py-3 px-5" x-text='item.killer_name + " | " + item.killer_guild'></td>

                                        <td class="py-3 px-5" x-text='item.timestamp'></td>
                                            <td class=" whitespace-nowrap border-t py-3 px-5 text-end">
                                                <form method="post" :action="'<?php echo e(Auth::user()->url); ?>' + '?id=' + item.Id + '&name=' + item.Name" >
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('patch'); ?>
                                                    <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','style' => 'success','text' => 'Request','xBind:disabled' => 'item.allowed_gears == 0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','style' => 'success','text' => 'Request','x-bind:disabled' => 'item.allowed_gears == 0']); ?>
                                                         <?php $__env->slot('icon', null, []); ?> <?php if (isset($component)) { $__componentOriginal4564dd23ed213a0e67d69fc217beeba7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4564dd23ed213a0e67d69fc217beeba7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.button.create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.button.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4564dd23ed213a0e67d69fc217beeba7)): ?>
<?php $attributes = $__attributesOriginal4564dd23ed213a0e67d69fc217beeba7; ?>
<?php unset($__attributesOriginal4564dd23ed213a0e67d69fc217beeba7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4564dd23ed213a0e67d69fc217beeba7)): ?>
<?php $component = $__componentOriginal4564dd23ed213a0e67d69fc217beeba7; ?>
<?php unset($__componentOriginal4564dd23ed213a0e67d69fc217beeba7); ?>
<?php endif; ?> <?php $__env->endSlot(); ?>
                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
                                                </form>
                                            </td>
                                    </tr>
                            </template>
                            </tbody>
                        </table>
                </div>
            </template>


         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9914b83164616fc828dee591eec2a324)): ?>
<?php $attributes = $__attributesOriginal9914b83164616fc828dee591eec2a324; ?>
<?php unset($__attributesOriginal9914b83164616fc828dee591eec2a324); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9914b83164616fc828dee591eec2a324)): ?>
<?php $component = $__componentOriginal9914b83164616fc828dee591eec2a324; ?>
<?php unset($__componentOriginal9914b83164616fc828dee591eec2a324); ?>
<?php endif; ?>



</section>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/regears/partials/deathlog.blade.php ENDPATH**/ ?>