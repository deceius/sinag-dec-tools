<section x-data="builds">
    <?php if (isset($component)) { $__componentOriginal9914b83164616fc828dee591eec2a324 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9914b83164616fc828dee591eec2a324 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card.table','data' => ['class' => 'mt-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.card.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-6']); ?>
         <?php $__env->slot('title', null, []); ?> 
            <?php echo e(__('Build Generator')); ?>

         <?php $__env->endSlot(); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginale5a9133b910c265c6141ef7a07401ae3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5a9133b910c265c6141ef7a07401ae3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.master-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.master-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5a9133b910c265c6141ef7a07401ae3)): ?>
<?php $attributes = $__attributesOriginale5a9133b910c265c6141ef7a07401ae3; ?>
<?php unset($__attributesOriginale5a9133b910c265c6141ef7a07401ae3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5a9133b910c265c6141ef7a07401ae3)): ?>
<?php $component = $__componentOriginale5a9133b910c265c6141ef7a07401ae3; ?>
<?php unset($__componentOriginale5a9133b910c265c6141ef7a07401ae3); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('buttons', null, []); ?> 
            <form method="post"  >
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['xBind:disabled' => 'isLoading','xOn:click' => 'saveBuild()','style' => 'success','text' => 'Create Build']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-bind:disabled' => 'isLoading','x-on:click' => 'saveBuild()','style' => 'success','text' => 'Create Build']); ?>
                     <?php $__env->slot('icon', null, []); ?> <?php if (isset($component)) { $__componentOriginal4564dd23ed213a0e67d69fc217beeba7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4564dd23ed213a0e67d69fc217beeba7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.button.create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.button.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4564dd23ed213a0e67d69fc217beeba7)): ?>
<?php $attributes = $__attributesOriginal4564dd23ed213a0e67d69fc217beeba7; ?>
<?php unset($__attributesOriginal4564dd23ed213a0e67d69fc217beeba7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4564dd23ed213a0e67d69fc217beeba7)): ?>
<?php $component = $__componentOriginal4564dd23ed213a0e67d69fc217beeba7; ?>
<?php unset($__componentOriginal4564dd23ed213a0e67d69fc217beeba7); ?>
<?php endif; ?> <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
            </form>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('content', null, []); ?> 
                <div class="overflow-x-auto" >
                    <table id="table" class="min-w-full table-auto">
                            <thead class="font-medium">
                                <tr class=" border-gray-700 dark:border-gray-700">
                                    <th scope="col" class="text-start py-3 px-5">
                                        <?php echo e(__('Role')); ?>

                                    </th>
                                    <th scope="col" class="text-start py-3 px-5">
                                        <?php echo e(__('Equipment')); ?>

                                    </th>
                                    <th scope="col" class="text-start py-3 px-5">
                                        <?php echo e(__('Others')); ?>

                                    </th>
                                    <th scope="col" class="text-start py-3 px-5">
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr class="border-t-2 border-gray-700 dark:border-gray-700 text-start ">
                                    <td class="border-t py-3 px-5 align-top">
                                        <?php if (isset($component)) { $__componentOriginal3d764d9aa1637ee21fbd47e006854817 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d764d9aa1637ee21fbd47e006854817 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.select','data' => ['xModel' => 'data.role_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-model' => 'data.role_id']); ?>
                                            <template x-for="(role, index) in roles">
                                                <option x-bind:value="index" x-text="role"/>
                                            </template>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d764d9aa1637ee21fbd47e006854817)): ?>
<?php $attributes = $__attributesOriginal3d764d9aa1637ee21fbd47e006854817; ?>
<?php unset($__attributesOriginal3d764d9aa1637ee21fbd47e006854817); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d764d9aa1637ee21fbd47e006854817)): ?>
<?php $component = $__componentOriginal3d764d9aa1637ee21fbd47e006854817; ?>
<?php unset($__componentOriginal3d764d9aa1637ee21fbd47e006854817); ?>
<?php endif; ?>
                                    </td>
                                    <td class="border-t py-3 px-5 align-top">
                                        <template x-for="item in equipment">
                                            <div class="mb-2">
                                                <img x-show="item.items.length == 0" class="opacity-25 grayscale" x-bind:src="`https://render.albiononline.com/v1/item/QUESTITEM_TOKEN_ADC_FRAME?size=32`">
                                                <div :class="{'animate-pulse': isLoading}">
                                                    <template x-for="item_id in item.items">
                                                        <img x-on:click="removeItem(item, item_id)" :class="{'opacity-25 grayscale': item_id == null }" class="inline" x-bind:src="`https://render.albiononline.com/v1/item/${ item_id ? item_id : 'QUESTITEM_TOKEN_ADC_FRAME'}?size=32`" tooltip="item.type">
                                                    </template>
                                                </div>
                                                <?php if (isset($component)) { $__componentOriginal0d0ae8bef4b4e146c2af1b2494139103 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d0ae8bef4b4e146c2af1b2494139103 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.search','data' => ['model' => 'item.filter','clickMethod' => 'load(item)','xBind:placeholder' => 'item.type','xBind:disabled' => 'item.disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model' => 'item.filter','click-method' => 'load(item)','x-bind:placeholder' => 'item.type','x-bind:disabled' => 'item.disabled']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d0ae8bef4b4e146c2af1b2494139103)): ?>
<?php $attributes = $__attributesOriginal0d0ae8bef4b4e146c2af1b2494139103; ?>
<?php unset($__attributesOriginal0d0ae8bef4b4e146c2af1b2494139103); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d0ae8bef4b4e146c2af1b2494139103)): ?>
<?php $component = $__componentOriginal0d0ae8bef4b4e146c2af1b2494139103; ?>
<?php unset($__componentOriginal0d0ae8bef4b4e146c2af1b2494139103); ?>
<?php endif; ?>
                                            </div>
                                        </template>
                                    </td>
                                    <td class="border-t py-3 px-5 align-top">
                                        <template x-for="item in consumables">
                                            <div class="mb-2">
                                                <img x-show="item.items.length == 0" class="opacity-25 grayscale" x-bind:src="`https://render.albiononline.com/v1/item/QUESTITEM_TOKEN_ADC_FRAME?size=32`">
                                                <div :class="{'animate-pulse': isLoading}">
                                                    <template x-for="item_id in item.items">
                                                        <img x-on:click="removeItem(item, item_id)" :class="{'opacity-25 grayscale': item_id == null }" class="inline" x-bind:src="`https://render.albiononline.com/v1/item/${ item_id ? item_id : 'QUESTITEM_TOKEN_ADC_FRAME'}?size=32`" tooltip="item.type">
                                                    </template>
                                                </div>
                                                <?php if (isset($component)) { $__componentOriginal0d0ae8bef4b4e146c2af1b2494139103 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d0ae8bef4b4e146c2af1b2494139103 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.search','data' => ['model' => 'item.filter','clickMethod' => 'load(item)','xBind:placeholder' => 'item.type','xBind:disabled' => 'item.disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model' => 'item.filter','click-method' => 'load(item)','x-bind:placeholder' => 'item.type','x-bind:disabled' => 'item.disabled']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d0ae8bef4b4e146c2af1b2494139103)): ?>
<?php $attributes = $__attributesOriginal0d0ae8bef4b4e146c2af1b2494139103; ?>
<?php unset($__attributesOriginal0d0ae8bef4b4e146c2af1b2494139103); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d0ae8bef4b4e146c2af1b2494139103)): ?>
<?php $component = $__componentOriginal0d0ae8bef4b4e146c2af1b2494139103; ?>
<?php unset($__componentOriginal0d0ae8bef4b4e146c2af1b2494139103); ?>
<?php endif; ?>
                                            </div>
                                        </template>
                                    </td>
                                </tr>
                                <tr class="border-t-2 border-transparent dark:border-transparent text-start ">
                                    <td class="border-t py-3 px-5 align-top" colspan="4">
                                        <?php if (isset($component)) { $__componentOriginal034cad61c0993bf87a0316661a720dd6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal034cad61c0993bf87a0316661a720dd6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.input.text','data' => ['placeholder' => 'Notes','xModel' => 'data.notes','class' => 'min-w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.input.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Notes','x-model' => 'data.notes','class' => 'min-w-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal034cad61c0993bf87a0316661a720dd6)): ?>
<?php $attributes = $__attributesOriginal034cad61c0993bf87a0316661a720dd6; ?>
<?php unset($__attributesOriginal034cad61c0993bf87a0316661a720dd6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal034cad61c0993bf87a0316661a720dd6)): ?>
<?php $component = $__componentOriginal034cad61c0993bf87a0316661a720dd6; ?>
<?php unset($__componentOriginal034cad61c0993bf87a0316661a720dd6); ?>
<?php endif; ?>
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                </div>


         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9914b83164616fc828dee591eec2a324)): ?>
<?php $attributes = $__attributesOriginal9914b83164616fc828dee591eec2a324; ?>
<?php unset($__attributesOriginal9914b83164616fc828dee591eec2a324); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9914b83164616fc828dee591eec2a324)): ?>
<?php $component = $__componentOriginal9914b83164616fc828dee591eec2a324; ?>
<?php unset($__componentOriginal9914b83164616fc828dee591eec2a324); ?>
<?php endif; ?>



</section>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/builds/partials/generator.blade.php ENDPATH**/ ?>