<section>
    <?php if (isset($component)) { $__componentOriginal9914b83164616fc828dee591eec2a324 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9914b83164616fc828dee591eec2a324 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.card.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('title', null, []); ?> 
            <?php echo e(__('Discord Info')); ?>

         <?php $__env->endSlot(); ?>
         <?php $__env->slot('icon', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginale5a9133b910c265c6141ef7a07401ae3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5a9133b910c265c6141ef7a07401ae3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.master-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.master-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5a9133b910c265c6141ef7a07401ae3)): ?>
<?php $attributes = $__attributesOriginale5a9133b910c265c6141ef7a07401ae3; ?>
<?php unset($__attributesOriginale5a9133b910c265c6141ef7a07401ae3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5a9133b910c265c6141ef7a07401ae3)): ?>
<?php $component = $__componentOriginale5a9133b910c265c6141ef7a07401ae3; ?>
<?php unset($__componentOriginale5a9133b910c265c6141ef7a07401ae3); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('content', null, []); ?> 
            <div class="overflow-x-auto">
                <table id="table" class="min-w-full">
                        <tbody>
                            <tr class="border-t-2 border-gray-700 dark:border-gray-700 text-start">
                                <td class="border-t py-3 px-5 font-medium"  width="20%" > Discord Name</td>
                                <td class="border-t py-3 px-5"><?php echo e($user->global_name); ?></td>
                            </tr>
                            <tr class="border-t-2 border-gray-700 dark:border-gray-700 text-start">
                                <td class="border-t py-3 px-5 font-medium"> Roles</td>
                                <td class="border-t py-3 px-5"><?php echo e($user->roles); ?></td>
                            </tr>
                        </tbody>
                    </table>
            </div>

         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9914b83164616fc828dee591eec2a324)): ?>
<?php $attributes = $__attributesOriginal9914b83164616fc828dee591eec2a324; ?>
<?php unset($__attributesOriginal9914b83164616fc828dee591eec2a324); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9914b83164616fc828dee591eec2a324)): ?>
<?php $component = $__componentOriginal9914b83164616fc828dee591eec2a324; ?>
<?php unset($__componentOriginal9914b83164616fc828dee591eec2a324); ?>
<?php endif; ?>



</section>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/profile/partials/discord-account-info.blade.php ENDPATH**/ ?>