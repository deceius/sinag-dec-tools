<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['links']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['links']); ?>
<?php foreach (array_filter((['links']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<nav class="isolate -space-x-px rounded-md shadow-sm">
    <template x-for="(link, index) in <?php echo e($links); ?>">
        <?php if (isset($component)) { $__componentOriginal456ba5c86ab1f204acd44a96c2d2f440 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal456ba5c86ab1f204acd44a96c2d2f440 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.pagination.link','data' => ['xOn:click' => 'loadPage(link.url)','xText' => 'link.label','index' => 'index',':class' => '{ \'bg-white dark:bg-gray-800\' : !link.active, \'bg-gray-900 text-white\' : link.active, \'text-gray-900 hover:bg-gray-100\' : !link.active, \'rounded-l-md\' : index == 0, \'rounded-r-md\' : index == '.e($links).'.length - 1 }']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.pagination.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'loadPage(link.url)','x-text' => 'link.label','index' => 'index',':class' => '{ \'bg-white dark:bg-gray-800\' : !link.active, \'bg-gray-900 text-white\' : link.active, \'text-gray-900 hover:bg-gray-100\' : !link.active, \'rounded-l-md\' : index == 0, \'rounded-r-md\' : index == '.e($links).'.length - 1 }']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal456ba5c86ab1f204acd44a96c2d2f440)): ?>
<?php $attributes = $__attributesOriginal456ba5c86ab1f204acd44a96c2d2f440; ?>
<?php unset($__attributesOriginal456ba5c86ab1f204acd44a96c2d2f440); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal456ba5c86ab1f204acd44a96c2d2f440)): ?>
<?php $component = $__componentOriginal456ba5c86ab1f204acd44a96c2d2f440; ?>
<?php unset($__componentOriginal456ba5c86ab1f204acd44a96c2d2f440); ?>
<?php endif; ?>
    </template>
</nav>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/components/ui/pagination.blade.php ENDPATH**/ ?>