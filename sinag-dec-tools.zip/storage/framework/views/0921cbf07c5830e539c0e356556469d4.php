<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['clickMethod', 'model']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['clickMethod', 'model']); ?>
<?php foreach (array_filter((['clickMethod', 'model']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="inline-flex items-center bg-transparent dark:bg-gray-900 disabled:bg-gray-200 border border-gray-300 dark:border-gray-700 rounded-md text-xs text-gray-700 uppercase tracking-widest shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:ring-offset-2 disabled:opacity-25 transition ease-in-out duration-150">
    <input x-model="<?php echo e($model); ?>" x-on:keyup.enter="<?php echo e($clickMethod); ?>" <?php echo $attributes->merge(['class' => 'bg-transparent dark:bg-gray-900 text-sm dark:text-gray-400 border-0 px-5 rounded-lg focus:ring-0 disabled:opacity-25 ']); ?> type="text" name="search">
    <button x-on:click="<?php echo e($clickMethod); ?>" type="button" class="px-3 py-2 ">
        <?php if (isset($component)) { $__componentOriginalcd80e5511cf0a60b698275469362b0ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd80e5511cf0a60b698275469362b0ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.search-bar-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.search-bar-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd80e5511cf0a60b698275469362b0ad)): ?>
<?php $attributes = $__attributesOriginalcd80e5511cf0a60b698275469362b0ad; ?>
<?php unset($__attributesOriginalcd80e5511cf0a60b698275469362b0ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd80e5511cf0a60b698275469362b0ad)): ?>
<?php $component = $__componentOriginalcd80e5511cf0a60b698275469362b0ad; ?>
<?php unset($__componentOriginalcd80e5511cf0a60b698275469362b0ad); ?>
<?php endif; ?>
    </button>
</div>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/components/ui/search.blade.php ENDPATH**/ ?>