<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalea3ff48ecc2c47bd6007ee32944844eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.header','data' => ['title' => ''.e('Profile').'','subtitle' => ''.e(Auth::user()->ao_character_id ? 'Below are your Character and SINAG Discord details.' : 'Bind your AO Character to your SINAG Discord account. The character must be in the guild IN-GAME for it to appear in IGN Lookup.').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e('Profile').'','subtitle' => ''.e(Auth::user()->ao_character_id ? 'Below are your Character and SINAG Discord details.' : 'Bind your AO Character to your SINAG Discord account. The character must be in the guild IN-GAME for it to appear in IGN Lookup.').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb)): ?>
<?php $attributes = $__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb; ?>
<?php unset($__attributesOriginalea3ff48ecc2c47bd6007ee32944844eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea3ff48ecc2c47bd6007ee32944844eb)): ?>
<?php $component = $__componentOriginalea3ff48ecc2c47bd6007ee32944844eb; ?>
<?php unset($__componentOriginalea3ff48ecc2c47bd6007ee32944844eb); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <?php if(Auth::user()->ao_character_id): ?>
                <?php echo $__env->make('profile.partials.discord-account-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('profile.partials.ao-character-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('profile.partials.update-ao-character', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/profile/edit.blade.php ENDPATH**/ ?>