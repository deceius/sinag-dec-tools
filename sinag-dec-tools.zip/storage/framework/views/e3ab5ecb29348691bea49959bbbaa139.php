
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title']); ?>
<?php foreach (array_filter((['title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div <?php echo e($attributes->merge(['class' => 'bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg'])); ?>>
    <?php if(isset($title)): ?>
    <div  <?php echo e($title->attributes->merge(['class' => 'p-6 text-gray-900  dark:text-gray-400'])); ?>>
        <div class="flex justify-between h-5 items-center">
            <div class="flex space-x-2 items-center leading-tight font-semibold">
                    <?php echo e($icon ?? ''); ?>

                    <span><?php echo e($title ?? ''); ?></span>
            </div>
            <div class="space-x-2 flex items-center">
                <?php echo e($buttons ?? ''); ?>

            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal91da587e3ed37d9e80f8e31879836b4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91da587e3ed37d9e80f8e31879836b4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.separator','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91da587e3ed37d9e80f8e31879836b4f)): ?>
<?php $attributes = $__attributesOriginal91da587e3ed37d9e80f8e31879836b4f; ?>
<?php unset($__attributesOriginal91da587e3ed37d9e80f8e31879836b4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91da587e3ed37d9e80f8e31879836b4f)): ?>
<?php $component = $__componentOriginal91da587e3ed37d9e80f8e31879836b4f; ?>
<?php unset($__componentOriginal91da587e3ed37d9e80f8e31879836b4f); ?>
<?php endif; ?>
    <?php endif; ?>

    <div <?php echo e($content->attributes->merge(['class' => 'text-gray-900  dark:text-gray-400'])); ?>>
        <?php echo e($content); ?>

    </div>
</div>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/components/ui/card/table.blade.php ENDPATH**/ ?>