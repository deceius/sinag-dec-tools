<img src="<?php echo e(url('assets/sinag-logo.png')); ?>" <?php echo e($attributes); ?>/>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/components/application-logo.blade.php ENDPATH**/ ?>