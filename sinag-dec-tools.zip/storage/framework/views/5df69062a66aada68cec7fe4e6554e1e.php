
<div class="w-16">
    <img <?php echo e($attributes->merge(['class' => 'inline'])); ?>x-bind:src="`https://render.albiononline.com/v1/item/${ <?php echo e($item); ?> }?size=64`">
</div>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/components/custom/item-img.blade.php ENDPATH**/ ?>