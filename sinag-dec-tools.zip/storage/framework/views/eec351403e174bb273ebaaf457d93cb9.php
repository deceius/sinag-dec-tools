
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['style' => 'primary', 'type' => 'button']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['style' => 'primary', 'type' => 'button']); ?>
<?php foreach (array_filter((['style' => 'primary', 'type' => 'button']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
switch ($style) {
    case 'secondary':
        $classes = 'inline-flex items-center p-2 bg-white dark:bg-gray-800 disabled:opacity-25 border dark:border-gray-700 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:ring-offset-2 disabled:opacity-25 transition ease-in-out duration-150';
        break;
    case 'success':
        $classes = 'inline-flex items-center p-2 bg-green-600 disabled:opacity-25 border border-transparent rounded-md font-semibold text-xs text-gray-600 dark:text-gray-100 uppercase tracking-widest hover:bg-green-500 active:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition ease-in-out duration-150';
        break;
    case 'danger':
        $classes = 'inline-flex items-center p-2 bg-red-600 disabled:opacity-25 border border-transparent rounded-md font-semibold text-xs text-gray-600 dark:text-gray-400 uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150';
        break;
    default:
        $classes = 'inline-flex items-center p-2 bg-gray-800 disabled:opacity-25 border dark:border-gray-700 rounded-md font-semibold text-xs text-gray-600 dark:text-gray-400 uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:ring-offset-2 transition ease-in-out duration-150';
        break;
}
?>
<button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <div class="flex space-x-2 items-center h-5">
        <?php echo e($slot); ?>

   </div>
  </button>
<?php /**PATH E:\Projects\sinag-dec-tools\resources\views/components/ui/button/button-icon.blade.php ENDPATH**/ ?>