<img src="{{ url('assets/sinag-logo.png')}}" {{ $attributes }}/>
