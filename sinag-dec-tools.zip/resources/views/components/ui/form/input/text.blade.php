
<input {!! $attributes->merge(['class' => 'text-sm  dark:text-gray-400  dark:border-gray-700 bg-transparent dark:bg-gray-900 border-gray-300 focus:border-indigo-500 focus:ring-indigo-600 rounded-md shadow-sm disabled:opacity-50']) !!}>
