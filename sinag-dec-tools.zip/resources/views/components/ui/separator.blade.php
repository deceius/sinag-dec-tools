<span {{ $attributes->merge(['class' => 'block h-px w-full px-4 focus:outline-none transition duration-150 ease-in-out border-b dark:border-gray-700']) }}>&nbsp;</span>
