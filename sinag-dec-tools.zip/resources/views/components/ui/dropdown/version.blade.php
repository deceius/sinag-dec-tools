<span {{ $attributes->merge(['class' => 'block w-full px-4 py-2 text-center text-xs text-slate-400 focus:outline-none transition duration-150 ease-in-out']) }}>v2.0.1</span>
