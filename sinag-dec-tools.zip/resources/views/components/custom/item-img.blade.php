
<div class="w-16">
    <img {{ $attributes->merge(['class' => 'inline']) }}x-bind:src="`https://render.albiononline.com/v1/item/${ {{ $item }} }?size=64`">
</div>
